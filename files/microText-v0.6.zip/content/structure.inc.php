<?php

# Данные о странице
$title = 'Структура файлов microText';
$keywords = '';
$description = '';
$template = 'info';
$page_blocks = 'reviews, donate';

# Содержание страницы
$content = <<<EOF
<p>Структура файлов.</p>
EOF;
